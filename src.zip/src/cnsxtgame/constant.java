package cnsxtgame;

public class constant {
	public static final int gamewidth=800;
	public static final int gameheight=500;

}

package cnsxtgame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.net.URL;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;



public class mygameframe extends Frame{
	Image playerplane=GameUtil.getImage("images/playerplane .png");
	Image bg=GameUtil.getImage("images/bg.jpg");
	explode baozha;
	Date starttime=new Date();
	Date endtime;
	int period,SCORE;
	

	plane plane=new plane(playerplane,350,350);
	shell[] shells=new shell[30];
	
	
	private Image offScreenImage=null;
	public void update(Graphics g) {
		if(offScreenImage==null)
			offScreenImage=this.createImage(constant.gamewidth,constant.gameheight);
		Graphics goff=offScreenImage.getGraphics();
		paint(goff);
		g.drawImage(offScreenImage, 0, 0, null);
			
	}//˫���弼�����������˸��
	public void paint(Graphics g) {
		g.drawImage(bg, 0, 0, null);
		plane.drawself(g);//hua feiji
		
		for(int i=0;i<shells.length;i++) {
			shells[i].draw(g);
			boolean peng=shells[i].getrect().intersects(plane.getrect());//��ײ���
			if(0<plane.x||plane.x<constant.gamewidth-plane.width-10) {
				plane.dl=true;
				plane.dr=true;
			}
			if(plane.y<constant.gameheight-plane.height||plane.y>40) {
				plane.dd=true;
				plane.du=true;
			}
			if(plane.x<0) {
				plane.dl=false;
			}
			if(plane.x>constant.gamewidth-plane.width-10) {
				plane.dr=false;
			}
			if(plane.y<40) {
				plane.du=false;
			}
			if(plane.y>constant.gameheight-plane.height) {
				plane.dd=false;
			}
			if(peng) {
				plane.live=false;
				if(baozha==null) {//���ն���ըһ��
				baozha=new explode(plane.x-250,plane.y-300);
				endtime=new Date();
				period=(int)((endtime.getTime()-starttime.getTime())/1000);
				SCORE=(int)((endtime.getTime()-starttime.getTime())/10);
				}
				baozha.draw(g);
				if(!plane.live){//��ʱ
				g.setColor(Color.WHITE);
				Font f=new Font("���Ŀ���",Font.BOLD,50);
				g.setFont(f);
				g.drawString("ʱ��"+period+"��"+"\n"+"����"+SCORE+"��",(int)plane.x,(int)plane.y);
				}
			}
			
			
		}
	}
	
	class PaintThread extends Thread{
		public void run() {
			while(true) {
				repaint();
				try {
					Thread.sleep(10);
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	

	class Keymonitor extends KeyAdapter{//���̼���

		@Override
		public void keyPressed(KeyEvent e) {
			plane.adddirection(e);
		}

		@Override
		public void keyReleased(KeyEvent e) {
			plane.minusdirection(e);
		}
	}
		
	
	
	
	public void lautchFrame(){
		this.setTitle("�ɻ��ܵ�С��Ϸ����made by wyh");
		this.setVisible(true);
		this.setSize(constant.gamewidth, constant.gameheight);
		this.setLocation(150, 150);
		
		this.addWindowListener(new WindowAdapter()
				{
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
				});
		new PaintThread().start();//�����߳� 
		addKeyListener(new Keymonitor());//�������Ӽ��̼���
		
		for(int i=0;i<shells.length;i++) {
			shells[i]=new shell();
		}
		
		
	}
	
public static void main(String[] args){
	mygameframe f=new mygameframe();
	f.lautchFrame();
}
}

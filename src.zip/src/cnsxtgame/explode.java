package cnsxtgame;

import java.awt.Graphics;
import java.awt.Image;

public class explode {
	double x,y;
	static Image[] imgs=new Image[14];
	static {
		for(int i=0;i<14;i++) {
			imgs[i]=GameUtil.getImage("images/explode/timg"+(i+1)+".png");
			imgs[i].getWidth(null);
		}
	}

int count;
public void draw(Graphics g) {
	if(count<=13) {
		g.drawImage(imgs[count], (int)x, (int)y, null);
		count++;
	}
}
public explode(double x,double y) {
	this.x=x;
	this.y=y;
}
}
package cnsxtgame;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;

public class plane extends gameobject{
	int speed=3;
	boolean left,up,right,down;
	boolean dl=true;
	boolean dr=true;
	boolean du=true;
	boolean dd=true;
	boolean live=true;
	
	 public void drawself(Graphics g) {
		 if(live) {
		 g.drawImage(img,(int)x, (int)y, null);
		 if(dl) {
		 if(left) {
			 x-=speed;
		 }
		 }
		 if(dr) {
		 if(right) {
			 x+=speed;
		 }
		 }
		 if(du) {
		 if(up) {
			 y-=speed;
		 }
		 }
		 if(dd) {
		 if(down) {
			 y+=speed;
		 }
		 }
	 }
	 }
public plane(Image img, int x, int y) {
	this.img=img;
	this.x=x;
	this.y=y;
	this.width=img.getWidth(null);
	this.height=img.getHeight(null);
}
public void adddirection(KeyEvent e) {
	switch(e.getKeyCode()) {
	case 65:
	left=true;
	break;
	case 68:
	right=true;
	break;
	case 87:
	up=true;
	break;
	case 83:
	down=true;
	break;
	}

}
public void minusdirection(KeyEvent e) {
	switch(e.getKeyCode()) {
	case 65:
	left=false;
	break;
	case 68:
	right=false;
	break;
	case 87:
	up=false;
	break;
	case 83:
	down=false;
	break;
	}
	
	
}


}
